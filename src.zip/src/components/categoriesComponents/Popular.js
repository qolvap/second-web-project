import popularityItem from "../popularityItem";
import Footer from "../Footer";


function Popular(){
    return (
        <>
        <popularityItem/>
        <Footer/>
        </>
    )
}
export default Popular;