const popularItems = [
    {
      id: 1,
      name: "Name",
      price: "100€",
      pupularity: true
    },
    {
      id: 2,
      name: "Name",
      price: "150€",
      pupularity: true
    },
    {
      id: 3,
      name: "Name",
      price: "80€",
      pupularity: true
    },
    {
      id: 4,
      name: "Name",
      price: "100€",
      pupularity: true
    },
    {
      id: 5,
      name: "Name",
      price: "200€",
      pupularity: true
    },
    {
      id: 6,
      name: "Name",
      price: "200€",
      pupularity: true
    }
  ];
  
  export default popularItems;
  
