import React from "react"
import Career from "./styles/Career.css"

function Careers() {
    return (
        <div className="categories--section">
            <h1>Careers</h1>
        </div>
           
        
    )
}

export default Careers